# Small Mace (3D Model)

**Version:** 1.0.0
**Author:** MC_IRL_OFFICIAL
**Year:** 2026

## Description
Instructions included

## Printing Notes
Use the recommended printer and material from the project page. Adjust your
settings as needed and refer to the changelog for updates.

## License
Assets: CC BY-NC-SA 4.0 (see LICENSE_ASSETS.txt)
