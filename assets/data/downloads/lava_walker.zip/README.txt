# lava walker (Datapack)

**Version:** 1.0.0
**Author:** MC_IRL_OFFICIAL
**Year:** 2025

## Description
adds an enchantment for boots that lets you walk on lava you can find it in bastion chests please unzip

## Installation
1. Drop the ZIP into your world save folder under `datapacks/`.
2. Enable the datapack when creating or loading the world.
3. Enjoy the features — see the project page for details.

## License
Code: MIT (see LICENSE_CODE.txt)
Assets: CC BY-NC-SA 4.0 (see LICENSE_ASSETS.txt)
