summon minecraft:ender_pearl
tag @n[type=minecraft:ender_pearl,distance=..0.1] add elevator
data modify entity @n[type=minecraft:ender_pearl,distance=..0.1,tag=elevator] Owner set from entity @s UUID
tp @n[type=minecraft:ender_pearl,distance=..0.1,tag=elevator] ~ 100 ~
advancement revoke @s only elevator:use_elevator