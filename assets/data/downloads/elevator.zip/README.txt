# Elevator (Datapack)

**Version:** 1.0.0
**Author:** MC_IRL_OFFICIAL
**Year:** 2026

## Description
this datapack adds the Elevator item like in some minigames right click to use please unzip

## Installation
1. Drop the ZIP into your world save folder under `datapacks/`.
2. Enable the datapack when creating or loading the world.
3. Enjoy the features — see the project page for details.

## License
Code: MIT (see LICENSE_CODE.txt)
Assets: CC BY-NC-SA 4.0 (see LICENSE_ASSETS.txt)
