Project: Mace
Type: Datapack
Version: 1.0.0
Author: MC_IRL_OFFICIAL

Description:
A Minecraft datapack related to the mace feature.

Licensing:
- Datapack code: MIT License (see LICENSE_CODE.txt)
- Original assets: CC BY-NC-SA 4.0 (see LICENSE_ASSETS.txt)

Notes:
This package may not contain any Minecraft/Mojang game files or original assets.
Minecraft and related assets are © Mojang AB / Microsoft.
