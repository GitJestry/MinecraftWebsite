Pickaxe Desk Model – placeholder pack
====================================

This ZIP is a placeholder for the pickaxe desk model.

Replace this file with your real STL files before publishing:

- Export your STL parts (handle, head, any supports) from your 3D tool.
- Create a new ZIP named `pickaxe-desk-model.zip`.
- Put all STL files and a short README into the ZIP.
- Upload it to the `downloads/` folder of the website.

